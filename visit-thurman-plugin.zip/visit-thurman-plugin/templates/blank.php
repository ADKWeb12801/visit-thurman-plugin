<?php
/**
 * Blank template.
 *
 * This file is intentionally left almost blank. It's used by class-vt-templates.php
 * to prevent the active theme from loading its own template file (like single.php or archive.php)
 * after our plugin has already rendered the content. This is a compatibility measure for
 * page builders like Breakdance that can disable theme template files.
 *
 * @package VisitThurman
 */

// No content needed here.
